package com.fournotfour.myapps.mygovernmentschemes;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.fournotfour.myapps.mygovernmentschemes.pojo.Scheme;

import java.util.ArrayList;
import java.util.Arrays;

public class SchemeListActivity extends AppCompatActivity {
    String selectedSchemeForSelectedMinistry;
    ListView selectedMinistrySchemesListView;
    String[] selectedMinistrySchemesListItem;
    ArrayList<Scheme> listOfAllSchemesForSelectedMinistry = new ArrayList<>();
    Scheme selectedScheme = new Scheme();
    SearchView searchView;
    String selectedMinsitry;
    myDbAdapter helper;
    String appLanguageCode = "en-us";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_list);
        /**
         * Getting input data from previous screen
         */
        Bundle bundle = getIntent().getExtras();

        if (bundle != null && bundle.getParcelableArrayList("listOfAllSchemesForSelectedMinistry") != null) {
            listOfAllSchemesForSelectedMinistry = new ArrayList<>();
            listOfAllSchemesForSelectedMinistry = bundle.getParcelableArrayList("listOfAllSchemesForSelectedMinistry");

            //  Log.d("tag", " selectedScheme before bundle 1111 :"+listOfAllSchemesForSelectedMinistry.get(0).getSchemeObjective());
        }
        if (bundle != null && bundle.getString("selectedMinsitry") != null) {
            selectedMinsitry = bundle.getString("selectedMinsitry");
        }
        if (bundle != null && bundle.getString("appLanguageCode") != null) {
            appLanguageCode = bundle.getString("appLanguageCode");
        }


        //Log.d("tag", " SlistOfAllSchemesForSelectedMinistry :"+listOfAllSchemesForSelectedMinistry.size());

        /**
         * ToolBar
         */
        String toolbarTitle = getString(R.string.app_ministry_name);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(selectedMinsitry);
        setSupportActionBar(toolbar);
        /**
         *Ministry List View
         */
        searchView = (SearchView) findViewById(R.id.searchSchemeView);
        helper = new myDbAdapter(this);
        selectedMinistrySchemesListView = (ListView) findViewById(R.id.schemeListViewForSelectedMininstry);

        selectedMinistrySchemesListItem = getSchemesForSelectedMinistry(listOfAllSchemesForSelectedMinistry);
        //Log.d("tag", " Scheme Count for selected ministry :"+selectedMinistrySchemesListItem[0].toString());
        final ArrayAdapter<String> selectedMinistrySchemesAdapater = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, selectedMinistrySchemesListItem) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convertView, parent);
                if (position % 2 == 1) {
                    tv.setBackgroundColor(Color.parseColor("#FFEFD5"));
                } else {
                    tv.setBackgroundColor(Color.parseColor("#F0F8FF"));
                }
                tv.setGravity(Gravity.CENTER);

                return tv;
            }
        };
        selectedMinistrySchemesListView.setClickable(true);
        selectedMinistrySchemesListView.setAdapter(selectedMinistrySchemesAdapater);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                if (Arrays.asList(selectedMinistrySchemesListItem).contains(query)) {
                    selectedMinistrySchemesAdapater.getFilter().filter(query);
                } else {
                    Toast.makeText(SchemeListActivity.this, "No Match found", Toast.LENGTH_LONG).show();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                selectedMinistrySchemesAdapater.getFilter().filter(newText);
                return false;
            }
        });

        selectedMinistrySchemesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                selectedScheme = new Scheme();

                selectedSchemeForSelectedMinistry = selectedMinistrySchemesAdapater.getItem(position);

                selectedScheme = helper.getSchemeDetails_Eng(selectedSchemeForSelectedMinistry, appLanguageCode);

                //  Log.d("tag", " selectedScheme before bundle 456 :"+selectedScheme.getSchemeName());
                Intent toastIntent = new Intent(getApplicationContext(), SchemeActivity.class);
                toastIntent.putParcelableArrayListExtra("selectedScheme", selectedScheme);
                startActivity(toastIntent);

            }
        });
    }

    private String[] getSchemesForSelectedMinistry(ArrayList<Scheme> listOfAllSchemesForSelectedMinistry) {

        String[] schemesArray = new String[listOfAllSchemesForSelectedMinistry.size()];
        int index = 0;
        for (Scheme scheme : listOfAllSchemesForSelectedMinistry) {
            schemesArray[index] = scheme.getSchemeName();
            index++;
        }

        return schemesArray;
    }
}
