package com.fournotfour.myapps.mygovernmentschemes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fournotfour.myapps.mygovernmentschemes.pojo.ListOfMinistry;
import com.fournotfour.myapps.mygovernmentschemes.pojo.MinistrySchemesList;
import com.fournotfour.myapps.mygovernmentschemes.pojo.RootNode;
import com.fournotfour.myapps.mygovernmentschemes.pojo.Scheme;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;


public class MinistryListActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener {

    String appLanguageCode = "en_US";
    Locale myLocale;
    myDbAdapter helper;


    ListView listView;
    String[] ministerListItemFromdb;
    SearchView searchView;

    String selectedMinsitry = "";

    Toolbar toolbar;

    ArrayList<Scheme> listOfAllSchemesForSelectedMinistry = new ArrayList<>();
    ArrayAdapter<String> ministryAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ministry_list);
        listView = (ListView) findViewById(R.id.ministryListView);
        searchView = (SearchView) findViewById(R.id.searchView);

        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        if (sharedPreferences.contains("My_Lang")) {
            if (sharedPreferences.getString("My_Lang", "en_US").equalsIgnoreCase("en_US")) {
                appLanguageCode = "en_US";
            } else {
                appLanguageCode = "ta";
            }
        }
        helper = new myDbAdapter(this);
        //setLocale(appLanguageCode);
        if (appLanguageCode.equalsIgnoreCase("en_US")) {
            ministerListItemFromdb = helper.getAllMinsitryListFromDbInEnglish();
        } else if (appLanguageCode.equalsIgnoreCase("ta")) {
            ministerListItemFromdb = helper.getAllMinsitryListFromDbInTamil();
        }
        /**
         * ToolBar
         */
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.app_home_name);
        setSupportActionBar(toolbar);

        /**
         * Ministry List View
         */
        ministryAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, ministerListItemFromdb) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView tv = (TextView) super.getView(position, convertView, parent);
                if (position % 2 == 1) {
                    tv.setBackgroundColor(Color.parseColor("#FFEFD5"));
                } else {
                    tv.setBackgroundColor(Color.parseColor("#F0F8FF"));
                }
                tv.setGravity(Gravity.CENTER);
                return tv;
            }
        };


        listView.setClickable(false);
        listView.setAdapter(ministryAdapter);
        enableSearch();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {


                listOfAllSchemesForSelectedMinistry = new ArrayList<>();
                selectedMinsitry = ministryAdapter.getItem(position);
                if (appLanguageCode.equalsIgnoreCase("en_US")) {
                    //listOfAllSchemesForSelectedMinistry=   helper.getSchemesForSelectedMinistryFromDb_Eng(position+1);
                    listOfAllSchemesForSelectedMinistry = helper.getSchemesForSelectedMinistryFromDb_Eng_ByName(selectedMinsitry);
                } else if (appLanguageCode.equalsIgnoreCase("ta")) {
                    // listOfAllSchemesForSelectedMinistry=   helper.getSchemesForSelectedMinistryFromDb_Tam(position+1);
                    listOfAllSchemesForSelectedMinistry = helper.getSchemesForSelectedMinistryFromDb_Tam_ByName(selectedMinsitry);
                }
                Toast.makeText(getApplicationContext(), selectedMinsitry, Toast.LENGTH_SHORT).show();
                Intent toastIntent = new Intent(getApplicationContext(), SchemeListActivity.class);
                //  Log.d("tag", " listOfAllSchemesForSelectedMinistry :"+listOfAllSchemesForSelectedMinistry.size());
                Bundle b = new Bundle();
                b.putString("selectedMinsitry", selectedMinsitry);
                b.putString("appLanguageCode", appLanguageCode);
                // Log.d("tag", " selectedScheme before bundle 123 :"+listOfAllSchemesForSelectedMinistry.get(0).getSchemeObjective());
                b.putParcelableArrayList("listOfAllSchemesForSelectedMinistry", listOfAllSchemesForSelectedMinistry);
                toastIntent.putExtras(b);

                startActivity(toastIntent);

            }
        });

    }


    private void createDataToAirTable() {
        try {
            String urlToSave = "https://api.airtable.com/v0/appFlbKu9N93KYHS1/Shops";
            String urlToRetrieve = "https://api.airtable.com/v0/appFlbKu9N93KYHS1/Shops?maxRecords=3&view=Grid%20view";
            String toSave = "{\n"
                    + "  \"records\": [\n"
                    + "    {\n"
                    + "      \"fields\": {\n"
                    + "        \"ShopName\": \"Demo Shop one1\",\n"
                    + "        \"UserName\": \"user1\",\n"
                    + "        \"UserPassword\": \"user1\"\n"
                    + "      }\n"
                    + "    },\n"
                    + "    {\n"
                    + "      \"fields\": {\n"
                    + "        \"ShopName\": \"dd2\",\n"
                    + "        \"UserName\": \"dd2\",\n"
                    + "        \"UserPassword\": \"dd2\"\n"
                    + "      }\n"
                    + "    }\n"
                    + "  ]\n"
                    + "}";

            URL obj = new URL(urlToSave);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestMethod("POST");
            String basicAuth = "Bearer keyLqd8vI00iFYmvu";
            conn.setRequestProperty("Authorization", basicAuth);
            conn.setDoOutput(true);
            OutputStream out = conn.getOutputStream();
            out.write(toSave.getBytes());
            out.flush();
            out.close();
//
            int responseCode = conn.getResponseCode();
            Log.d("tag", "Response Code for POST:" + responseCode);
            //
//            obj = new URL(urlToRetrieve);
//            conn = (HttpURLConnection) obj.openConnection();
//            conn.setRequestProperty("Content-Type", "application/json");
//            conn.setRequestMethod("GET");
//            basicAuth = "Bearer keyLqd8vI00iFYmvu";
//            conn.setRequestProperty("Authorization", basicAuth);
//            responseCode = conn.getResponseCode();
//            InputStreamReader isr = new InputStreamReader(conn.getInputStream());
//            BufferedReader br = new BufferedReader(isr);
//            String inputLine = "";
//            StringBuffer response = new StringBuffer();
//            while ((inputLine = br.readLine()) != null) {
//                response.append(inputLine);
//            }
//            br.close();
//            System.out.println("Response Code for retrieval :" + responseCode);
//            System.out.println("Data Retrieved Successfully " + response.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.Rating:
                Log.d("tag", "RATE_US MENU CLICKED");
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("market://details?id=" + this.getPackageName())));
                } catch (android.content.ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("http://play.google.com/store/apps/details?id=" + this.getPackageName())));
                }
                return true;

            case R.id.Contact:
                Log.d("tag", "CONTACT_US MENU CLICKED");
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{ConstantUtility.CONTACT_US_MAIL_ID});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "subject");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Type Your Query or Message Here!!!");
                emailIntent.setType("message/rfc822");
                startActivity(Intent.createChooser(emailIntent, "Choose an Email client :"));
                return true;
            case R.id.Language:
                Log.d("tag", " LANGUAGE MENU CLICKED");
                return true;
            case R.id.languageTamil:
                appLanguageCode = "ta";
                setLocale(appLanguageCode);
                createOrUpdateContent();
                enableSearch();

                return true;
            case R.id.languageEnglish:
                appLanguageCode = "en_US";
                setLocale(appLanguageCode);
                createOrUpdateContent();
                enableSearch();

                return true;
            case R.id.media_route_menu_item:
                startActivity(new Intent("android.settings.CAST_SETTINGS"));
                return true;

            case R.id.ShareApp:
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "My application name");
                    String shareMessage = "\nLet me recommend you this awesome application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {
                    //e.toString();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void enableSearch() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                if (Arrays.asList(ministerListItemFromdb).contains(query)) {
                    ministryAdapter.getFilter().filter(query);
                } else {
                    Toast.makeText(MinistryListActivity.this, "No Match found", Toast.LENGTH_LONG).show();
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ministryAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    private void createOrUpdateContent() {
        toolbar.setTitle(R.string.app_home_name);
        if (appLanguageCode.equalsIgnoreCase("en_US")) {
            ministerListItemFromdb = helper.getAllMinsitryListFromDbInEnglish();
        } else if (appLanguageCode.equalsIgnoreCase("ta")) {
            ministerListItemFromdb = helper.getAllMinsitryListFromDbInTamil();
        }
        ministryAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, ministerListItemFromdb) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView tv = (TextView) super.getView(position, convertView, parent);
                if (position % 2 == 1) {
                    tv.setBackgroundColor(Color.parseColor("#FFEFD5"));
                } else {
                    tv.setBackgroundColor(Color.parseColor("#F0F8FF"));
                }
                tv.setGravity(Gravity.CENTER);
                return tv;
            }
        };


        listView.setClickable(true);
        listView.setAdapter(ministryAdapter);
        searchView.setQueryHint(String.valueOf(getText(R.string.ministryQueryText)));
    }

    private void setLocale(String languageCode) {
        myLocale = new Locale(languageCode);
        Locale.setDefault(myLocale);
        Resources res = this.getResources();
        Configuration configuration = new Configuration();
        configuration.setLocale(myLocale);
        res.updateConfiguration(configuration, res.getDisplayMetrics());
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor = getSharedPreferences("settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();
        editor.commit();

    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        restartActivity();
    }

    private void restartActivity() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
}