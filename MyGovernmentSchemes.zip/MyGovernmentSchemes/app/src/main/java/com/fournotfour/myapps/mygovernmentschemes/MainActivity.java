package com.fournotfour.myapps.mygovernmentschemes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fournotfour.myapps.mygovernmentschemes.pojo.ListOfMinistry;
import com.fournotfour.myapps.mygovernmentschemes.pojo.MinistrySchemesList;
import com.fournotfour.myapps.mygovernmentschemes.pojo.RootNode;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSettings;
    Button btnRead;
    Button btnQuiz;
    Button btnAboutUs;

    Locale myLocale;
    myDbAdapter helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(this);
        btnRead = findViewById(R.id.btnRead);
        btnRead.setOnClickListener(this);
        btnQuiz = findViewById(R.id.btnQuiz);
        btnQuiz.setOnClickListener(this);
        btnAboutUs = findViewById(R.id.btnAboutUs);
        btnAboutUs.setOnClickListener(this);
        setLocale("en_US");
        /**
         * Reading Json file and creating database
         */
        helper = new myDbAdapter(this);
        try {
            String jsonArrayEng = readJSONFromAssetEng();
            String jsonArrayTam = readJSONFromAssetTam();
            ObjectMapper objectMapper = new ObjectMapper();
            RootNode rootNodeEnglish = objectMapper.readValue(jsonArrayEng, RootNode.class);
            RootNode rootNodeTamil = objectMapper.readValue(jsonArrayTam, RootNode.class);
            createDbData(rootNodeEnglish, rootNodeTamil);
            Toast.makeText(getApplicationContext(), "Db Data Created successfully", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onClick(View view) {
        Log.d("tag", " Button clicked");
        switch (view.getId()) {
            case R.id.btnRead:
                Intent intent = new Intent(getApplicationContext(), MinistryListActivity.class);
                startActivity(intent);
                break;
            case R.id.btnSettings:
                selectLanguage();
                break;
            case R.id.btnQuiz:
                Toast.makeText(getApplicationContext(), "Not Supported", Toast.LENGTH_LONG).show();
                break;
            case R.id.btnAboutUs:
                aboutUs();
                break;

        }
    }

    private void aboutUs() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setMessage(Html.fromHtml("<html>\n" +
                "<head>\n" +
                "<body>\n" +
                "<h1>My Goverernment Schemes </h1>\n" +
                "<p>This App helps you to get the details on central governmnet schemes.</p>\n" +
                "<p>We FourNotFourApps team's aims at providing the highly stable and efficient application to the user. We are doing this in our leisure of the team members. \n" +
                "We are expecting a good support and suggestion from you all.</p>\n" +
                "<p style=\"color:red\" >Developer</p>\n" +
                "<p>MR.Karthikeyan (Software Developer)</p>\n" +
                "<p style=\"color:red\" >Tester</p>\n" +
                "<p>Mr.XYZ</p>\n" +
                "<p style=\"color:red\">Data Collection Team</p>\n" +
                "<p>Ms.Rajeshwari (M.Tech)</p>\n" +
                "Contact us:<a href=\"fournotfourapps@gmail.com\">fournotfourapps@gmail.com</a>\n" +
                "</body>\n" +
                "</html>"));
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                    }
                });

        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    private void selectLanguage() {
        final String[] selectedLanguage = {"en_US"};
        Log.d("tag", " Language Selections");
        final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setTitle(R.string.pickLanguage);
        final String[] listItems = getResources().getStringArray(R.array.language_array);
        dialog.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (listItems[i].equalsIgnoreCase("tamil")) {
                    selectedLanguage[0] = "ta";
                } else {
                    selectedLanguage[0] = "en_US";
                }
                setLocale(selectedLanguage[0]);

            }
        });
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        Toast.makeText(getApplicationContext(), "Language Updated" + selectedLanguage[0], Toast.LENGTH_SHORT).show();
                    }
                });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Toast.makeText(getApplicationContext(), "cancel is clicked", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    private void setLocale(String languageCode) {
        myLocale = new Locale(languageCode);
        Locale.setDefault(myLocale);
        Resources res = this.getResources();
        Configuration configuration = new Configuration();
        configuration.setLocale(myLocale);
        res.updateConfiguration(configuration, res.getDisplayMetrics());
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor = getSharedPreferences("settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", languageCode);
        editor.apply();
        editor.commit();

    }

    private void createDbData(RootNode rootNodeEnglish, RootNode rootNodeTamil) {
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        if (!sharedPreferences.contains("isDbEngCreated") && !sharedPreferences.contains("isDbTamCreated")) {
            SharedPreferences.Editor editor = getSharedPreferences("settings", MODE_PRIVATE).edit();
            ListOfMinistry listOfMinistryEng = new ListOfMinistry();
            MinistrySchemesList ministrySchemesListEng = new MinistrySchemesList();
            ListOfMinistry listOfMinistryTam = new ListOfMinistry();
            MinistrySchemesList ministrySchemesListTam = new MinistrySchemesList();
            for (int i = 0; i < rootNodeEnglish.getListOfMinistries().size(); i++) {
                listOfMinistryEng = new ListOfMinistry();
                listOfMinistryEng = (ListOfMinistry) rootNodeEnglish.getListOfMinistries().get(i);
                helper.insertEnglishMinistryData(listOfMinistryEng);
                ministrySchemesListEng = new MinistrySchemesList();
                for (int j = 0; j < listOfMinistryEng.getMinistrySchemesList().size(); j++) {
                    ministrySchemesListEng = (MinistrySchemesList) listOfMinistryEng.getMinistrySchemesList().get(j);
                    // Log.d("tag", "BEFORE INSERION =>"+ministrySchemesListEng.getSchemeDesc());
                    helper.insertEnglishSchemeData(ministrySchemesListEng, listOfMinistryEng.getMinistryId());
                }

            }
            editor.putBoolean("isDbEngCreated", true);
            editor.apply();
            editor.commit();
            for (int i = 0; i < rootNodeTamil.getListOfMinistries().size(); i++) {
                listOfMinistryTam = new ListOfMinistry();
                listOfMinistryTam = (ListOfMinistry) rootNodeTamil.getListOfMinistries().get(i);
                helper.insertTamilMinistryData(listOfMinistryTam);
                ministrySchemesListTam = new MinistrySchemesList();
                for (int j = 0; j < listOfMinistryTam.getMinistrySchemesList().size(); j++) {
                    ministrySchemesListTam = (MinistrySchemesList) listOfMinistryTam.getMinistrySchemesList().get(j);
                    helper.insertTamilSchemeData(ministrySchemesListTam, listOfMinistryTam.getMinistryId());
                }
            }
            editor.putBoolean("isDbTamCreated", true);
            editor.apply();
            editor.commit();

        }
    }

    public String readJSONFromAssetEng() {
        String json = null;
        try {
            InputStream is = getAssets().open("inputData.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    public String readJSONFromAssetTam() {
        String json = null;
        try {
            InputStream is = getAssets().open("inputDataTamil.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

}
