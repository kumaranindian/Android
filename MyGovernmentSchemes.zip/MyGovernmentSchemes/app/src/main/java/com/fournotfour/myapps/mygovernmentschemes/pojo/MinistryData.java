package com.fournotfour.myapps.mygovernmentschemes.pojo;

public class MinistryData {

    private String SubjectName;
    private int imageId;
    public MinistryData(String subjectName, int image) {
        this.SubjectName = subjectName;
        this.imageId = image;
    }

    public String getSubjectName() {
        return SubjectName;
    }

    public void setSubjectName(String subjectName) {
        SubjectName = subjectName;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}
