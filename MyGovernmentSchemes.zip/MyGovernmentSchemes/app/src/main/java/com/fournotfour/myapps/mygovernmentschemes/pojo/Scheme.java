package com.fournotfour.myapps.mygovernmentschemes.pojo;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.stream.Stream;

public class Scheme extends ArrayList<Parcelable> implements Parcelable {

    private Integer schemeId;
    private Integer schemeMinistryId;
    private  String schemeUIid;
    private  String schemeName;
    private String schemeDescription;
    private  String schemeObjective;
    private  String schemeEligibility;
    private  String schemeTargetGroup;
    private  String schemeDepartment;
    private  String schemeMiscDetails;

    public String getSchemeDepartment() {
        return schemeDepartment;
    }

    public void setSchemeDepartment(String schemeDepartment) {
        this.schemeDepartment = schemeDepartment;
    }

    public Scheme() {
    }

    public Scheme(Integer schemeId, Integer schemeMinistryId, String schemeUIid, String schemeName,
                  String schemeDescription, String schemeObjective, String schemeEligibility,
                  String schemeTargetGroup, String schemeDepartment, String schemeMiscDetails) {
        this.schemeId = schemeId;
        this.schemeMinistryId = schemeMinistryId;
        this.schemeUIid = schemeUIid;
        this.schemeName = schemeName;
        this.schemeDescription = schemeDescription;
        this.schemeObjective = schemeObjective;
        this.schemeEligibility = schemeEligibility;
        this.schemeTargetGroup = schemeTargetGroup;
        this.schemeDepartment = schemeDepartment;
        this.schemeMiscDetails = schemeMiscDetails;
    }

    public String getSchemeUIid() {
        return schemeUIid;
    }

    public void setSchemeUIid(String schemeUIid) {
        this.schemeUIid = schemeUIid;
    }

    public String getSchemeObjective() {
        return schemeObjective;
    }

    public void setSchemeObjective(String schemeObjective) {
        this.schemeObjective = schemeObjective;
    }

    public String getSchemeEligibility() {
        return schemeEligibility;
    }

    public void setSchemeEligibility(String schemeEligibility) {
        this.schemeEligibility = schemeEligibility;
    }

    public String getSchemeTargetGroup() {
        return schemeTargetGroup;
    }

    public void setSchemeTargetGroup(String schemeTargetGroup) {
        this.schemeTargetGroup = schemeTargetGroup;
    }

    public String getSchemeMiscDetails() {
        return schemeMiscDetails;
    }

    public void setSchemeMiscDetails(String schemeMiscDetails) {
        this.schemeMiscDetails = schemeMiscDetails;
    }


    public Integer getSchemeId() {
        return schemeId;
    }

    public void setSchemeId(Integer schemeId) {
        this.schemeId = schemeId;
    }

    public Integer getSchemeMinistryId() {
        return schemeMinistryId;
    }

    public void setSchemeMinistryId(Integer schemeMinistryId) {
        this.schemeMinistryId = schemeMinistryId;
    }

    public static Creator<Scheme> getCREATOR() {
        return CREATOR;
    }
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(schemeName);
        dest.writeString(schemeDescription);
        dest.writeString(schemeObjective);
        dest.writeString(schemeEligibility);
        dest.writeString(schemeTargetGroup);
        dest.writeString(schemeDepartment);
        dest.writeString(schemeMiscDetails);
    }
    protected Scheme(Parcel in) {
        schemeName = in.readString();
        schemeDescription = in.readString();
        schemeObjective = in.readString();
        schemeEligibility = in.readString();
        schemeTargetGroup = in.readString();
        schemeDepartment = in.readString();
        schemeMiscDetails = in.readString();
    }

    public static final Creator<Scheme> CREATOR = new Creator<Scheme>() {
        @Override
        public Scheme createFromParcel(Parcel in) {
            return new Scheme(in);
        }

        @Override
        public Scheme[] newArray(int size) {
            return new Scheme[size];
        }
    };

    public String getSchemeName() {
        return schemeName;
    }

    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }

    public String getSchemeDescription() {
        return schemeDescription;
    }

    public void setSchemeDescription(String schemeDescription) {
        this.schemeDescription = schemeDescription;
    }

    @Override
    public int describeContents() {
        return 0;
    }



    @NonNull
    @Override
    public Stream<Parcelable> stream() {
        return null;
    }
}
