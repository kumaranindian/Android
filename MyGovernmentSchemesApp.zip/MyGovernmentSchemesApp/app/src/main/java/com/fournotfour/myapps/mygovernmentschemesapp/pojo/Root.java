package com.fournotfour.myapps.mygovernmentschemesapp.pojo;


import java.util.ArrayList;
import java.util.List;
public class Root
{
    private List<Records> records;

    public void setRecords(List<Records> records){
        this.records = records;
    }
    public List<Records> getRecords(){
        return this.records;
    }
}
