package com.fournotfour.myapps.mygovernmentschemesapp.pojo;


public class Records
{
    private String id;

    private Fields fields;

    private String createdTime;

    public void setId(String id){
        this.id = id;
    }
    public String getId(){
        return this.id;
    }
    public void setFields(Fields fields){
        this.fields = fields;
    }
    public Fields getFields(){
        return this.fields;
    }
    public void setCreatedTime(String createdTime){
        this.createdTime = createdTime;
    }
    public String getCreatedTime(){
        return this.createdTime;
    }
}

