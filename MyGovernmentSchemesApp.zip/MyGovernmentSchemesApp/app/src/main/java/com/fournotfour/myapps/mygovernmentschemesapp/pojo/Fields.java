package com.fournotfour.myapps.mygovernmentschemesapp.pojo;

import java.util.ArrayList;
import java.util.List;
public class Fields
{
    private int id;

    private String FileName;

    private String ProjectName;

    private String FileDescirption;

    private List<InputFile> InputFile;

    private String urlToFile;

    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setFileName(String FileName){
        this.FileName = FileName;
    }
    public String getFileName(){
        return this.FileName;
    }
    public void setProjectName(String ProjectName){
        this.ProjectName = ProjectName;
    }
    public String getProjectName(){
        return this.ProjectName;
    }
    public void setFileDescirption(String FileDescirption){
        this.FileDescirption = FileDescirption;
    }
    public String getFileDescirption(){
        return this.FileDescirption;
    }
    public void setInputFile(List<InputFile> InputFile){
        this.InputFile = InputFile;
    }
    public List<InputFile> getInputFile(){
        return this.InputFile;
    }
    public void setUrlToFile(String urlToFile){
        this.urlToFile = urlToFile;
    }
    public String getUrlToFile(){
        return this.urlToFile;
    }
}