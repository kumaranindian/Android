package com.fournotfour.myapps.mygovernmentschemesapp;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.fournotfour.myapps.mygovernmentschemesapp.pojo.Scheme;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;


public class SchemeActivity extends AppCompatActivity {


    private static final int STORAGE_CODE = 1000;
    private ListView schemeListView;
    Scheme scheme = new Scheme();
    String selectedMinsitry;
    String[] schemeListItem;
    private Button btnDownloadShare;
    private Button btnDownload;
    ProgressDialog p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme);


        schemeListView = findViewById(R.id.schemeListView);
        btnDownloadShare = findViewById(R.id.btnDownloadShare);
        btnDownload = findViewById(R.id.btnDownload);
        /**
         * Getting input data from previous screen
         */
        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.getParcelable("selectedScheme") != null) {
            scheme = bundle.getParcelable("selectedScheme");
        }if (bundle != null && bundle.getString("selectedMinsitry") != null) {
            selectedMinsitry = bundle.getString("selectedMinsitry");
        }

        // Log.d("tag", " selectedScheme after bundle 000:"+scheme.getSchemeObjective());
        /**
         * assging values to list view component
         */

        schemeListItem = prepareRecordToDisplay(scheme);
        // Log.d("tag", " selectedScheme after bundle :"+schemeListItem.length);
        //Log.d("tag", " Scheme Count for selected ministry :"+selectedMinistrySchemesListItem[0].toString());
        final ArrayAdapter<String> schemesAdapeter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, schemeListItem) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                int prevColor;

                TextView tv = (TextView) super.getView(position, convertView, parent);

                if (position % 2 == 1) {
                    tv.setGravity(Gravity.CENTER);
                    tv.setTextColor(Color.BLUE);
                    tv.setTypeface(null, Typeface.NORMAL);
                    tv.setBackgroundColor(Color.parseColor("#FFEFD5"));
                } else {
                    tv.setGravity(Gravity.LEFT);
                    tv.setWidth(40);
                    tv.setTextSize(20);
                    tv.setTextColor(Color.RED);
                    tv.setTypeface(null, Typeface.BOLD);
                    tv.setBackgroundColor(Color.parseColor("#F0F8FF"));
                }

                tv.setGravity(Gravity.CENTER);

                return tv;
            }
        };
        schemeListView.setAdapter(schemesAdapeter);
        /**
         * ToolBar
         */
        String toolbarTitle = getString(R.string.app_scheme_name);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(toolbarTitle);
        setSupportActionBar(toolbar);

        btnDownload.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View arg0) {
                try {
                    generatePDF("downloadAlone");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (DocumentException e) {
                    e.printStackTrace();
                }
            }
        });
        btnDownloadShare.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View arg0) {
                try {
                    generatePDF("downloadAndShare");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (DocumentException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    private void generatePDF(String mode) throws IOException, DocumentException {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            String[] permission = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
            requestPermissions(permission, STORAGE_CODE);
        } else {
            saveAndSharePdf(mode);
        }
    }

    private void saveAndSharePdf(String mode) throws IOException, DocumentException {
        Font redFontEnglish = new Font(Font.FontFamily.TIMES_ROMAN, 18,
                Font.BOLD, BaseColor.RED);
        Font blueFontEnglish = new Font(Font.FontFamily.TIMES_ROMAN, 15,
                Font.NORMAL, BaseColor.BLUE);
        Font redFontTamil = new Font(Font.getFamily(getAssets().open("HindMadurai-Bold.ttf").toString()), 18, Font.BOLD, BaseColor.RED);


        Document document = new Document();
        Log.e("filePath", String.valueOf(Locale.getDefault()));
        String fileName = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis());
        fileName=selectedMinsitry+"_"+scheme.getSchemeName()+"_"+fileName;
        File filePath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/" + fileName + ".pdf");

        try {
            SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            document.addAuthor("Four_Not_Four_Apps");
            Paragraph paragraph;

            if (sharedPreferences.contains("My_Lang")) {
                if (sharedPreferences.getString("My_Lang", "en_US").equalsIgnoreCase("en_US")) {
                    for (int i = 0; i < schemeListItem.length; i++) {
                        if (i % 2 == 0) {

                            paragraph = new Paragraph(schemeListItem[i].toString(), redFontEnglish);
                            paragraph.setAlignment(Element.ALIGN_CENTER);
                        } else {
                            paragraph = new Paragraph(schemeListItem[i].toString(), blueFontEnglish);
                            paragraph.setAlignment(Element.ALIGN_JUSTIFIED);
                        }
                        document.add(paragraph);
                    }
                    document.close();

                    Log.e("filePath", filePath.getAbsolutePath());
                    Toast.makeText(getApplicationContext(), "File Saved Successfully in below path \n " + filePath, Toast.LENGTH_SHORT).show();
                    if (mode.equalsIgnoreCase("downloadAndShare")) {
                        File pdfToShare = new File(filePath.getAbsolutePath());
                        Uri uri = null;
                        uri = FileProvider.getUriForFile(getApplicationContext(),".*",pdfToShare);
                        getApplicationContext().grantUriPermission("com.*", uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        Intent share = new Intent();
                        share.setAction(Intent.ACTION_SEND);
                        share.setType("application/pdf");
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        share.putExtra(Intent.EXTRA_STREAM, uri);
                        /* share.setPackage("com.whatsapp");*/
                        startActivity(Intent.createChooser(share, "Share Pdf!"));
                        getApplicationContext().revokeUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }

                } else {
                    Toast.makeText(getApplicationContext(), "Sorry, Tamil font not supported ", Toast.LENGTH_SHORT).show();
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
   /* String[] perms = {"android.permission.FINE_LOCATION", "android.permission.CAMERA"};

    int permsRequestCode = 200;
    requestPermissions(perms, permsRequestCode);

    @Override
    public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){

        switch(permsRequestCode){

            case 200:

                boolean locationAccepted = grantResults[0]==PackageManager.PERMISSION_GRANTED;
                boolean cameraAccepted = grantResults[1]==PackageManager.PERMISSION_GRANTED;

                break;

        }*/
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grandResults) {
        if (grandResults != null && grandResults.length > 0 && grandResults[0] == PackageManager.PERMISSION_GRANTED) {
            try {
                Toast.makeText(getApplicationContext(), "Thanks, Permission Granted to save pdf file...!", Toast.LENGTH_SHORT).show();
                saveAndSharePdf("savePdf");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (DocumentException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Sorry, Permission denied to save pdf file...!", Toast.LENGTH_SHORT).show();
        }
    }

    private String[] prepareRecordToDisplay(Scheme scheme) {

        String[] schemesToDipplay = new String[14];
        if (scheme.getSchemeName() != null && scheme.getSchemeName().toString().length() > 0) {
            schemesToDipplay[0] = getString(R.string.schemeName);
            schemesToDipplay[1] = scheme.getSchemeName().toString();
        }
        if (scheme.getSchemeObjective() != null && scheme.getSchemeObjective().toString().length() > 0) {
            schemesToDipplay[2] = getString(R.string.schemeObj);
            schemesToDipplay[3] = scheme.getSchemeObjective().toString();
        }
        if (scheme.getSchemeDescription() != null && scheme.getSchemeDescription().toString().length() > 0) {
            schemesToDipplay[4] = getString(R.string.schemeDesc);
            schemesToDipplay[5] = scheme.getSchemeDescription().toString();
        }
        if (scheme.getSchemeTargetGroup() != null && scheme.getSchemeTargetGroup().toString().length() > 0) {
            schemesToDipplay[6] = getString(R.string.schemeTarGrp);
            schemesToDipplay[7] = scheme.getSchemeTargetGroup().toString();
        }
        if (scheme.getSchemeEligibility() != null && scheme.getSchemeEligibility().toString().length() > 0) {
            schemesToDipplay[8] = getString(R.string.schemeEligible);
            schemesToDipplay[9] = scheme.getSchemeEligibility().toString();
        }
        if (scheme.getSchemeDepartment() != null && scheme.getSchemeDepartment().toString().length() > 0) {
            schemesToDipplay[10] = getString(R.string.schemeDepart);
            schemesToDipplay[11] = scheme.getSchemeDepartment().toString();
        }
        if (scheme.getSchemeMiscDetails() != null && scheme.getSchemeMiscDetails().toString().length() > 0) {
            schemesToDipplay[12] = getString(R.string.schemeMisc);
            schemesToDipplay[13] = scheme.getSchemeMiscDetails().toString();
        }
        return schemesToDipplay;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

/*
    private final class LongOperation extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p = new ProgressDialog(SchemeActivity.this);
            p.setMessage("Please wait...It is downloading");
            p.setIndeterminate(false);
            p.setCancelable(false);
            p.show();
        }

        @Override
        protected String doInBackground(Void... params) {
            //createDataToAirTable();
            try {
                savePdf();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (DocumentException e) {
                e.printStackTrace();
            }
            return "Executed";
        }

        @Override
        protected void onPostExecute(String result) {
            p.hide();
        }
    }*/
}

