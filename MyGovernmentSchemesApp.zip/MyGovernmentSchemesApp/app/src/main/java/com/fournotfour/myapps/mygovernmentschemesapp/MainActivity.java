package com.fournotfour.myapps.mygovernmentschemesapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fournotfour.myapps.mygovernmentschemesapp.pojo.ListOfMinistry;
import com.fournotfour.myapps.mygovernmentschemesapp.pojo.MinistrySchemesList;
import com.fournotfour.myapps.mygovernmentschemesapp.pojo.Root;
import com.fournotfour.myapps.mygovernmentschemesapp.pojo.RootNode;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView editText;
    Button btnSettings;
    Button btnRead;
    Button btnQuiz;
    Button btnAboutUs;
    Button btnExit;
    Button btnUpdate;

    Locale myLocale;
    myDbAdapter helper;
    AlertDialog.Builder builder;
    String appLanguageCode ;
    private ProgressDialog p;
    private static final int INTERNET_ACCESS_CODE = 2000;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      /*  if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }*/

        final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences settings = getSharedPreferences("settings", MODE_PRIVATE);
        boolean agreed = sharedPreferences.getBoolean("agreed", false);
         appLanguageCode = settings.getString("My_Lang", "en_US");
        if (!agreed) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("License agreement")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean("agreed", true);
                            editor.commit();
                            GetSchemeDetailsTask asyncTask = new GetSchemeDetailsTask();
                            asyncTask.execute();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putBoolean("agreed", false);
                            editor.commit();
                            doExit("exitWhileDisAgreeDisclaimer");
                        }
                    })
                    .setMessage("Test disclaimer")
                    .show();
        }
        editText = findViewById(R.id.editText);
        btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(this);
        btnRead = findViewById(R.id.btnRead);
        btnRead.setOnClickListener(this);
        btnQuiz = findViewById(R.id.btnQuiz);
        btnQuiz.setOnClickListener(this);
        btnAboutUs = findViewById(R.id.btnAboutUs);
        btnAboutUs.setOnClickListener(this);
        btnUpdate = findViewById(R.id.btnUpdateData);
        btnUpdate.setOnClickListener(this);
        btnExit = findViewById(R.id.btnExit);
        btnExit.setOnClickListener(this);

        setLocale(appLanguageCode);
        /**
         * Reading Json file and creating database
         */
        helper = new myDbAdapter(this);


    }

    private String readJSONFromAirtableTam() throws IOException {

        String urlToRetrieveAllDetails = "https://api.airtable.com/v0/appHrCyFvD2TrvXqH/InputFiles?maxRecords=3&view=Grid%20view";
        String urlToGetFileContent="" ;
        StringBuffer response = new StringBuffer();
        StringBuffer responseFileData = new StringBuffer();

        URL obj = new URL(urlToRetrieveAllDetails);
        HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestMethod("GET");
        String basicAuth = "Bearer keyLqd8vI00iFYmvu";
        conn.setRequestProperty("Authorization", basicAuth);
        int responseCode = conn.getResponseCode();
        InputStreamReader isr = new InputStreamReader(conn.getInputStream());
        BufferedReader br = new BufferedReader(isr);

        String inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            response.append(inputLine);
        }
        br.close();

        System.out.println("Response Code for readJSONFromAirtableTam :" + responseCode);
        // System.out.println("Data Retrieved Successfully using readJSONFromAirtableTam " + response.toString());

        Gson g = new Gson();
        Root rootNode = g.fromJson(response.toString(), Root.class);
        urlToGetFileContent=rootNode.getRecords().get(1).getFields().getUrlToFile();

        obj = new URL(urlToGetFileContent);
        conn = (HttpURLConnection) obj.openConnection();
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestMethod("GET");
        basicAuth = "Bearer keyLqd8vI00iFYmvu";
        conn.setRequestProperty("Authorization", basicAuth);
        responseCode = conn.getResponseCode();
        isr = new InputStreamReader(conn.getInputStream());
        br = new BufferedReader(isr);

        inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            responseFileData.append(inputLine);
        }
        br.close();

        System.out.println("Response Code for readJSONFromAirtableTam :" + responseCode);
        //System.out.println("Data Retrieved Successfully using readJSONFromAirtableTam " + responseFileData.toString());
        return responseFileData.toString();
    }

    private String readJSONFromAirtableEng() throws IOException {

        String urlToRetrieveAllDetails = "https://api.airtable.com/v0/appHrCyFvD2TrvXqH/InputFiles?maxRecords=3&view=Grid%20view";
        String urlToGetFileContent="" ;
        StringBuffer response = new StringBuffer();
        StringBuffer responseFileData = new StringBuffer();

        URL obj = new URL(urlToRetrieveAllDetails);
        HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestMethod("GET");
        String basicAuth = "Bearer keyLqd8vI00iFYmvu";
        conn.setRequestProperty("Authorization", basicAuth);
        int responseCode = conn.getResponseCode();
        InputStreamReader isr = new InputStreamReader(conn.getInputStream());
        BufferedReader br = new BufferedReader(isr);

        String inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            response.append(inputLine);
        }
        br.close();

        System.out.println("Response Code for readJSONFromAirtableEng :" + responseCode);
       // System.out.println("Data Retrieved Successfully using readJSONFromAirtableEng " + response.toString());

        Gson g = new Gson();
        Root rootNode = g.fromJson(response.toString(), Root.class);
        urlToGetFileContent=rootNode.getRecords().get(0).getFields().getUrlToFile();

         obj = new URL(urlToGetFileContent);
         conn = (HttpURLConnection) obj.openConnection();
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestMethod("GET");
         basicAuth = "Bearer keyLqd8vI00iFYmvu";
        conn.setRequestProperty("Authorization", basicAuth);
         responseCode = conn.getResponseCode();
         isr = new InputStreamReader(conn.getInputStream());
         br = new BufferedReader(isr);

         inputLine = "";
        while ((inputLine = br.readLine()) != null) {
            responseFileData.append(inputLine);
        }
        br.close();

        System.out.println("Response Code for readJSONFromAirtableEng :" + responseCode);
        //System.out.println("Data Retrieved Successfully using readJSONFromAirtableEng " + responseFileData.toString());
        return responseFileData.toString();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View view) {
        Log.d("tag", " Button clicked");
        switch (view.getId()) {
            case R.id.btnRead:
                Intent intent = new Intent(getApplicationContext(), MinistryListActivity.class);
                startActivity(intent);
                break;
            case R.id.btnSettings:
                selectLanguage();
                break;
            case R.id.btnUpdateData:

                GetSchemeDetailsTask asyncTask = new GetSchemeDetailsTask();
                asyncTask.execute();
                break;
            case R.id.btnQuiz:
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
                    String[] permission = {Manifest.permission.INTERNET};
                    requestPermissions(permission, INTERNET_ACCESS_CODE);
                } else {
                    getQuizSurvey();
                }

                /*Toast.makeText(getApplicationContext(), "Not Supported", Toast.LENGTH_LONG).show();*/
                break;
            case R.id.btnAboutUs:
                aboutUs();
                break;
            case R.id.btnExit:
                doExit("exitWhileBtnClick");
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grandResults) {
        if (grandResults != null && grandResults.length > 0 && grandResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Thanks, Permission Granted to take survey...!", Toast.LENGTH_SHORT).show();
            getQuizSurvey();
        } else {
            Toast.makeText(getApplicationContext(), "Sorry, Permission denied to take survey...!", Toast.LENGTH_SHORT).show();
        }
    }

    private void getQuizSurvey() {
        final String userName = Build.MANUFACTURER + "~" + Build.MODEL;
        final String[] surveyResult = {""};
        Log.d("tag", " Quiz Survey");
        final AlertDialog.Builder surveyDialog = new AlertDialog.Builder(MainActivity.this);
        surveyDialog.setTitle(R.string.quizSurvey);
        final String[] listItems = getResources().getStringArray(R.array.onlineQuizSurveyOption_array);
        surveyDialog.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                surveyResult[0] = listItems[i];
            }
        });

        surveyDialog.setPositiveButton("Submit",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        String surveyData = surveyResult[0].toString();
                        if (surveyData != null && surveyData.toString().trim().length() > 0) {

                            try {
                                AddSurveyDetailsTask asyncTask = new AddSurveyDetailsTask();
                                asyncTask.execute(userName, surveyData);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }else{
                            Toast.makeText(getApplicationContext(), "Sorry, no options were choosed in the survey", Toast.LENGTH_LONG).show();
                        }


                    }
                });
        surveyDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Toast.makeText(getApplicationContext(), "cancel is clicked", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = surveyDialog.create();
        alertDialog.show();
    }

    private void createDataToAirTable(String[] strings) {
        try {
            String urlToSave = "https://api.airtable.com/v0/apppFUtX7xgtRPV16/QuizSurveyResults ";
            String urlToRetrieve = "https://api.airtable.com/v0/apppFUtX7xgtRPV16/QuizSurveyResults ?maxRecords=3&view=Grid%20view";

            String toSave = "{\n" +
                    "  \"records\": [\n" +
                    "    {\n" +
                    "      \"fields\": {\n" +
                    "        \"suveyOption\": \":surveyAnswer:\",\n" +
                    "        \"UserModelDetails\": \":surverUserId:\"\n" +
                    "      }\n" +
                    "    }\n" +
                    "  ]\n" +
                    "}";
            toSave = toSave.replace(":surverUserId:", strings[0].toString());
            toSave = toSave.replace(":surveyAnswer:", strings[1].toString());
            URL obj = new URL(urlToSave);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestMethod("POST");
            String basicAuth = "Bearer keyLqd8vI00iFYmvu";
            conn.setRequestProperty("Authorization", basicAuth);
            conn.setDoOutput(true);
            OutputStream out = conn.getOutputStream();
            out.write(toSave.getBytes());
            out.flush();
            out.close();
//
            int responseCode = conn.getResponseCode();
            Log.d("tag", "Response Code for POST:" + responseCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void doExit(String exitWhileBtnClick) {
        /*if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
            builder = new AlertDialog.Builder(MainActivity.this);
        } else {
            builder = new AlertDialog.Builder(MainActivity.this, AlertDialog.BUTTON_NEUTRAL);
        }*/
        builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Thank You");
        builder.setMessage("Thank You For Using Our Application Please Give Us Your Suggestions and Feedback ");
        if (exitWhileBtnClick.equalsIgnoreCase("exitWhileBtnClick")) {
            builder.setNegativeButton("RATE US",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int which) {
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName())); // Add package name of your application
                            startActivity(intent);
                            Toast.makeText(MainActivity.this, "Thank you for your Rating",
                                    Toast.LENGTH_SHORT).show();
                        }


                    });
        }

        builder.setPositiveButton("QUIT",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        finish();
                    }
                });

        builder.show();

    }

    private void aboutUs() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setMessage(Html.fromHtml("<html>\n" +
                "<head>\n" +
                "<body>\n" +
                "<h1>My Goverernment Schemes </h1>\n" +
                "<p>This App helps you to get the details on central government schemes.</p>\n" +
                "<p>We FourNotFourApps team's aims at providing the highly stable and efficient application to the user. \n" +
                "We are expecting a good support and suggestion from you all.</p>\n" +
                "<p style=\"color:red\" >Developer</p>\n" +
                "<p>MR.Karthikeyan (Working in IT)</p>\n" +
                "<p style=\"color:red\" >Tester</p>\n" +
                "<p>Ms.Jagatheeshwari (UPSC Aspirant)</p>\n" +
                "<p style=\"color:red\">Data Collection Team</p>\n" +
                "<p>Ms.Rajeshwari (M.Tech)</p>\n" +
                "<p>Ms.Madhumathy (Working in IT)</p>\n" +
                "<p>Mr.Karthikraj (UPSC Aspirant)</p>\n" +
                "Contact us:<a href=\" fournotfourapps@gmail.com\">fournotfourapps@gmail.com</a>\n" +
                "</body>\n" +
                "</html>"));
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                    }
                });

        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    private void selectLanguage() {
        final String[] selectedLanguage = {"en_US"};
        //Log.d("tag", " Language Selections");
        final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setTitle(R.string.pickLanguage);
        final String[] listItems = getResources().getStringArray(R.array.language_array);
        int selectedIdx=-1;
        if(appLanguageCode.equalsIgnoreCase("en_US")){
            selectedIdx=1;
        }else  if(appLanguageCode.equalsIgnoreCase("ta")){
            selectedIdx=0;
        }
        dialog.setSingleChoiceItems(listItems, selectedIdx, new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (i==0) {
                    selectedLanguage[0] = "ta";
                } else   if (i==1) {
                    selectedLanguage[0] = "en_US";
                }else{
                    selectedLanguage[0] = appLanguageCode;
                }

            }
        });
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        setLocale(selectedLanguage[0]);
                    }
                });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Toast.makeText(getApplicationContext(), "cancel is clicked", Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    private void setLocale(String languageCode) {
        myLocale = new Locale(languageCode);
        Locale.setDefault(myLocale);
        Resources res = this.getResources();
        Configuration configuration = new Configuration();
        if(Build.VERSION.SDK_INT>16){
            configuration.locale=myLocale;
        }else{
            configuration.setLocale(myLocale);
        }

        res.updateConfiguration(configuration, res.getDisplayMetrics());
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor = getSharedPreferences("settings", MODE_PRIVATE).edit();
        appLanguageCode=languageCode;
        editor.putString("My_Lang", appLanguageCode);
        editor.apply();
        editor.commit();
        btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(this);
        btnSettings.setText(R.string.settings);

        btnRead = findViewById(R.id.btnRead);
        btnRead.setOnClickListener(this);
        btnRead.setText(R.string.next);

        btnQuiz = findViewById(R.id.btnQuiz);
        btnQuiz.setOnClickListener(this);
        btnQuiz.setText(R.string.quiz);

        btnAboutUs = findViewById(R.id.btnAboutUs);
        btnAboutUs.setOnClickListener(this);
        btnAboutUs.setText(R.string.about);

        btnUpdate = findViewById(R.id.btnUpdateData);
        btnUpdate.setOnClickListener(this);
        btnUpdate.setText(R.string.update);

        btnExit = findViewById(R.id.btnExit);
        btnExit.setOnClickListener(this);
        btnExit.setText(R.string.exit);


        editText= findViewById(R.id.editText);
        editText.setText(R.string.app_name);
    }

    private void createDbData(RootNode rootNodeEnglish, RootNode rootNodeTamil) {
            ListOfMinistry listOfMinistryEng = new ListOfMinistry();
            MinistrySchemesList ministrySchemesListEng = new MinistrySchemesList();
            ListOfMinistry listOfMinistryTam = new ListOfMinistry();
            MinistrySchemesList ministrySchemesListTam = new MinistrySchemesList();
            for (int i = 0; i < rootNodeEnglish.getListOfMinistries().size(); i++) {
                listOfMinistryEng = new ListOfMinistry();
                listOfMinistryEng = (ListOfMinistry) rootNodeEnglish.getListOfMinistries().get(i);
                helper.insertEnglishMinistryData(listOfMinistryEng);
                ministrySchemesListEng = new MinistrySchemesList();
                for (int j = 0; j < listOfMinistryEng.getMinistrySchemesList().size(); j++) {
                    ministrySchemesListEng = (MinistrySchemesList) listOfMinistryEng.getMinistrySchemesList().get(j);
                    // Log.d("tag", "BEFORE INSERION =>"+ministrySchemesListEng.getSchemeDesc());
                    helper.insertEnglishSchemeData(ministrySchemesListEng, listOfMinistryEng.getMinistryId());
                }

            }
            for (int i = 0; i < rootNodeTamil.getListOfMinistries().size(); i++) {
                listOfMinistryTam = new ListOfMinistry();
                listOfMinistryTam = (ListOfMinistry) rootNodeTamil.getListOfMinistries().get(i);
                helper.insertTamilMinistryData(listOfMinistryTam);
                ministrySchemesListTam = new MinistrySchemesList();
                for (int j = 0; j < listOfMinistryTam.getMinistrySchemesList().size(); j++) {
                    ministrySchemesListTam = (MinistrySchemesList) listOfMinistryTam.getMinistrySchemesList().get(j);
                    helper.insertTamilSchemeData(ministrySchemesListTam, listOfMinistryTam.getMinistryId());
                }
            }


    }

    public String readJSONFromAssetEng() {
        String json = null;
        try {
            InputStream is = getAssets().open("inputData.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    public String readJSONFromAssetTam() {
        String json = null;
        try {
            InputStream is = getAssets().open("inputDataTamil.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    private final class GetSchemeDetailsTask extends AsyncTask<String, Void, Boolean> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p = new ProgressDialog(MainActivity.this);
            p.setMessage("Please wait...Collecting Information on schemes!!!");
            p.setIndeterminate(false);
            p.setCancelable(false);
            p.show();
        }

        @Override
        protected Boolean doInBackground(String... strings) {
            boolean isUser = false;
            try {
/*            String jsonArrayEng = readJSONFromAssetEng();
            String jsonArrayTam = readJSONFromAssetTam();*/
                helper.dropAndCreateDb();
                String jsonArrayEng = readJSONFromAirtableEng();
                String jsonArrayTam = readJSONFromAirtableTam();
                ObjectMapper objectMapper = new ObjectMapper();
                RootNode rootNodeEnglish = objectMapper.readValue(jsonArrayEng, RootNode.class);
                RootNode rootNodeTamil = objectMapper.readValue(jsonArrayTam, RootNode.class);
                createDbData(rootNodeEnglish, rootNodeTamil);

            } catch (Exception e) {
                isUser = false;
            }


            return isUser;
        }


        @Override
        protected void onPostExecute(Boolean result) {
            p.hide();
            p.dismiss();
            Toast.makeText(getApplicationContext(), "Thanks , Data Collected Successfully...!", Toast.LENGTH_SHORT).show();
        }

    }

    private final class AddSurveyDetailsTask extends AsyncTask<String, Void, Boolean> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p = new ProgressDialog(MainActivity.this);
            p.setMessage("Please wait...submitting your response!!!");
            p.setIndeterminate(false);
            p.setCancelable(false);
            p.show();
        }

        @Override
        protected Boolean doInBackground(String... strings) {
            boolean isUser = false;
            try {
                createDataToAirTable(strings);
                isUser = true;
            } catch (Exception e) {
                isUser = false;
            }


            return isUser;
        }


        @Override
        protected void onPostExecute(Boolean result)
        {
            p.hide();
            p.dismiss();
            if(result){
                Toast.makeText(getApplicationContext(), "Thank for your time. Based on the survey we will enable quiz section in next release", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(), "Sorry for the inconvenience. Some Error happened while submitting response.", Toast.LENGTH_LONG).show();
            }

        }

    }
}
