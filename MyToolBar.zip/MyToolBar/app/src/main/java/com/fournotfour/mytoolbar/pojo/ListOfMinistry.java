package com.fournotfour.mytoolbar.pojo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ministryId",
        "ministryName",
        "ministrySchemesList"
})
public class ListOfMinistry {

    @JsonProperty("ministryId")
    private Integer ministryId;
    @JsonProperty("ministryName")
    private String ministryName;
    @JsonProperty("ministrySchemesList")
    private List<MinistrySchemesList> ministrySchemesList = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ministryId")
    public Integer getMinistryId() {
        return ministryId;
    }

    @JsonProperty("ministryId")
    public void setMinistryId(Integer ministryId) {
        this.ministryId = ministryId;
    }

    @JsonProperty("ministryName")
    public String getMinistryName() {
        return ministryName;
    }

    @JsonProperty("ministryName")
    public void setMinistryName(String ministryName) {
        this.ministryName = ministryName;
    }

    @JsonProperty("ministrySchemesList")
    public List<MinistrySchemesList> getMinistrySchemesList() {
        return ministrySchemesList;
    }

    @JsonProperty("ministrySchemesList")
    public void setMinistrySchemesList(List<MinistrySchemesList> ministrySchemesList) {
        this.ministrySchemesList = ministrySchemesList;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}