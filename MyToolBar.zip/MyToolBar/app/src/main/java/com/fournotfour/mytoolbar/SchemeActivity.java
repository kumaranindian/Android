package com.fournotfour.mytoolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.fournotfour.mytoolbar.pojo.Scheme;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Locale;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfWriter;

public class SchemeActivity extends AppCompatActivity {


    private ListView schemeListView;
    Scheme scheme=new Scheme();
    String[] schemeListItem;
    private TextToSpeech textToSpeech;
    private Button btnAudio;
    private Button btnDownload;
    private static final String LOG_TAG = "GeneratePDF";

    private String filename = "Sample.pdf";
    private String filepath = "MyPdfPath";

    private File pdfFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme);


        schemeListView= findViewById(R.id.schemeListView);

        btnAudio=findViewById(R.id.btnAudio);
        btnDownload=findViewById(R.id.btnDownload);
        /**
         * Getting input data from previous screen
         */
        Bundle bundle=getIntent().getExtras();
        if(bundle!=null && bundle.getParcelable("selectedScheme")!=null ){
            scheme= bundle.getParcelable("selectedScheme");
        }
        Log.d("tag", " selectedScheme after bundle 000:"+scheme.getSchemeObjective());
        /**
         * assging values to list view component
         */

        schemeListItem=prepareRecordToDisplay(scheme);
        Log.d("tag", " selectedScheme after bundle :"+schemeListItem.length);
        //Log.d("tag", " Scheme Count for selected ministry :"+selectedMinistrySchemesListItem[0].toString());
        final ArrayAdapter<String> schemesAdapeter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, schemeListItem){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){

                int prevColor;

                TextView tv = (TextView) super.getView(position,convertView,parent);

                if(position %2 == 1) {
                    tv.setTextColor(Color.BLUE);
                    tv.setTypeface(null, Typeface.NORMAL);
                    tv.setBackgroundColor(Color.parseColor("#FFEFD5"));
                }else {

                    tv.setWidth(40);
                    tv.setTextSize(20);
                    tv.setTextColor(Color.RED);
                    tv.setTypeface(null, Typeface.BOLD);
                    tv.setBackgroundColor(Color.parseColor("#F0F8FF"));
                }

                tv.setGravity(Gravity.CENTER);

                return tv;
            }
        };
        schemeListView.setAdapter(schemesAdapeter);
        /**
         * ToolBar
         */
        String toolbarTitle=getString(R.string.app_scheme_name);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(toolbarTitle);
        setSupportActionBar(toolbar);
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int ttsLang = textToSpeech.setLanguage(Locale.getDefault());

                    if (ttsLang == TextToSpeech.LANG_MISSING_DATA
                            || ttsLang == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "The Language is not supported!");
                    } else {
                        Log.i("TTS", "Language Supported.");
                    }
                    Log.i("TTS", "Initialization success.");
                } else {
                    Toast.makeText(getApplicationContext(), "TTS Initialization failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnAudio.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                String data="Selected Scheme Name is :"+scheme.getSchemeName().toString();

               // Log.i("TTS", "button clicked: " + data);
                int speechStatus = textToSpeech.speak(data, TextToSpeech.QUEUE_FLUSH, null);

                if (speechStatus == TextToSpeech.ERROR) {
                    Log.e("TTS", "Error in converting Text to Speech!");
                }
            }

        });

        btnDownload.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                generatePDF();


            }

        });
    }
    private void generatePDF() {
//reference to EditText

//create document object
        Document doc=new Document();
//output file path
        String outpath=Environment.getExternalStorageDirectory()+"/mypdf.pdf";
        try {
//create pdf writer instance
            PdfWriter.getInstance(doc, new FileOutputStream(outpath));
//open the document for writing
            doc.open();
//add paragraph to the document
            doc.add(new Paragraph("Test String"));
//close the document
            doc.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }


    private static boolean isExternalStorageReadOnly () {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }
    private static boolean isExternalStorageAvailable () {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }
    private String[] prepareRecordToDisplay(Scheme scheme) {
        String[] schemesToDipplay=new String[14];
        if(scheme.getSchemeName()!=null && scheme.getSchemeName().toString().length()>0){
            schemesToDipplay[0]= getString(R.string.schemeName);
            schemesToDipplay[1]=scheme.getSchemeName().toString();
        }if(scheme.getSchemeObjective()!=null && scheme.getSchemeObjective().toString().length()>0){
            schemesToDipplay[2]=getString(R.string.schemeObj);
            schemesToDipplay[3]=scheme.getSchemeObjective().toString();
        }if(scheme.getSchemeDescription()!=null && scheme.getSchemeDescription().toString().length()>0){
            schemesToDipplay[4]=getString(R.string.schemeDesc);
            schemesToDipplay[5]=scheme.getSchemeDescription().toString();
        }if(scheme.getSchemeTargetGroup()!=null && scheme.getSchemeTargetGroup().toString().length()>0){
            schemesToDipplay[6]=getString(R.string.schemeTarGrp);
            schemesToDipplay[7]=scheme.getSchemeTargetGroup().toString();
        }if(scheme.getSchemeEligibility()!=null && scheme.getSchemeEligibility().toString().length()>0){
            schemesToDipplay[8]=getString(R.string.schemeEligible);
            schemesToDipplay[9]=scheme.getSchemeEligibility().toString();
        }if(scheme.getSchemeDepartment()!=null && scheme.getSchemeDepartment().toString().length()>0){
            schemesToDipplay[10]=getString(R.string.schemeDepart);
            schemesToDipplay[11]=scheme.getSchemeDepartment().toString();
        }if(scheme.getSchemeMiscDetails()!=null && scheme.getSchemeMiscDetails().toString().length()>0){
            schemesToDipplay[12]=getString(R.string.schemeMisc);
            schemesToDipplay[13]=scheme.getSchemeMiscDetails().toString();
        }
       return  schemesToDipplay;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }
}
