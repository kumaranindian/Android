package com.fournotfour.mytoolbar;

public final  class ConstantUtility {

    public static final String CONTACT_US_MAIL_ID = "fournotfourapps@gmail.com";
}