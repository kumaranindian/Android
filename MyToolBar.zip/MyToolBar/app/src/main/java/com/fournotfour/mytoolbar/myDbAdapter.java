package com.fournotfour.mytoolbar;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.fournotfour.mytoolbar.pojo.ListOfMinistry;
import com.fournotfour.mytoolbar.pojo.MinistrySchemesList;
import com.fournotfour.mytoolbar.pojo.Scheme;

import java.util.ArrayList;

public class myDbAdapter {
    myDbHelper myhelper;
    public myDbAdapter(Context context)
    {
        myhelper = new myDbHelper(context);
    }

    /**
     *  INSERT QUERY TO MINISTRY TABLE (BOTH TAMI AND ENGLISH)
     * @param ministry
     * @return
     */
    public long insertEnglishMinistryData(ListOfMinistry ministry) {
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.MINISTRY_NAME, ministry.getMinistryName().toString());
        long id=0;
             id = dbb.insert(myDbHelper.MINISTRY_TABLE_NAME_ENG, null , contentValues);
             return id;
    }
    public long insertTamilMinistryData(ListOfMinistry ministry) {
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.MINISTRY_NAME, ministry.getMinistryName().toString());
        long id=0;
        id = dbb.insert(myDbHelper.MINISTRY_TABLE_NAME_TAM, null , contentValues);
        return id;
    }

    /**
     * INSERT QUERY TO SCHMES TABLE (BOTH TAMI AND ENGLISH)
     * @param ministrySchemesListTam
     * @param ministryId
     * @return
     */
    public long insertTamilSchemeData(MinistrySchemesList ministrySchemesListTam, int ministryId) {
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.SCHEME_UID, ministrySchemesListTam.getSchemeUiId());
        contentValues.put(myDbHelper.SCHEME_NAME, ministrySchemesListTam.getSchemeName());
        contentValues.put(myDbHelper.SCHEMES_DESC, ministrySchemesListTam.getSchemeDesc());
        contentValues.put(myDbHelper.SCHEMES_OBJECTIVE, ministrySchemesListTam.getSchemeObj());
        contentValues.put(myDbHelper.SCHEME_ELIGIBILITY, ministrySchemesListTam.getSchemeEligiiblity());
        contentValues.put(myDbHelper.SCHEME_TARGET, ministrySchemesListTam.getSchemeTargetGroup());
        contentValues.put(myDbHelper.SCHEME_DEPARTMENT, ministrySchemesListTam.getSchemeDepartments());
        contentValues.put(myDbHelper.SCHEME_MISC, ministrySchemesListTam.getSchemeMiscDetails());
        contentValues.put(myDbHelper.SCHEMES_MINISTRY_ID, ministryId);
        long id=0;
        id = dbb.insert(myDbHelper.SCHEMES_TABLE_NAME_TAMIL, null , contentValues);
        return id;
    }

    public long insertEnglishSchemeData(MinistrySchemesList ministrySchemesListEng, int ministryId) {
        SQLiteDatabase dbb = myhelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(myDbHelper.SCHEME_UID, ministrySchemesListEng.getSchemeUiId());
        contentValues.put(myDbHelper.SCHEME_NAME, ministrySchemesListEng.getSchemeName());
        contentValues.put(myDbHelper.SCHEMES_DESC, ministrySchemesListEng.getSchemeDesc());
        contentValues.put(myDbHelper.SCHEMES_OBJECTIVE, ministrySchemesListEng.getSchemeObj());
        contentValues.put(myDbHelper.SCHEME_ELIGIBILITY, ministrySchemesListEng.getSchemeEligiiblity());
        contentValues.put(myDbHelper.SCHEME_TARGET, ministrySchemesListEng.getSchemeTargetGroup());
        contentValues.put(myDbHelper.SCHEME_DEPARTMENT, ministrySchemesListEng.getSchemeDepartments());
        contentValues.put(myDbHelper.SCHEME_MISC, ministrySchemesListEng.getSchemeMiscDetails());
        contentValues.put(myDbHelper.SCHEMES_MINISTRY_ID, ministryId);
        long id=0;
        id = dbb.insert(myDbHelper.SCHEMES_TABLE_NAME_ENG, null , contentValues);
        return id;
    }

    /**
     * GET RECORDS FROM MINISTRY TABLE (BOTH TAMIL AND ENGLISH)
     * @return
     */
    public String[] getAllMinsitryListFromDbInEnglish(){
        String[] ministryArray;
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.MINISTRY_ID, myDbHelper.MINISTRY_NAME};
        Cursor cursor =db.query(myDbHelper.MINISTRY_TABLE_NAME_ENG,columns,null,null,null,null,null);
        ministryArray= new String[cursor.getCount()];
        StringBuffer buffer= new StringBuffer();
        int ministryCount=0;
        while (cursor.moveToNext()) {
            ministryArray[ministryCount]=cursor.getString(cursor.getColumnIndex(myDbHelper.MINISTRY_NAME));
            ministryCount++;
        }
        Log.d("tag","Ministry count from db is :"+ String.valueOf(ministryArray.length));
        return ministryArray;
    }
    public String[] getAllMinsitryListFromDbInTamil(){
        String[] ministryArray;
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.MINISTRY_ID, myDbHelper.MINISTRY_NAME};
        Cursor cursor =db.query(myDbHelper.MINISTRY_TABLE_NAME_TAM,columns,null,null,null,null,null);
        ministryArray= new String[cursor.getCount()];
        StringBuffer buffer= new StringBuffer();
        int ministryCount=0;
        while (cursor.moveToNext()) {
            ministryArray[ministryCount]=cursor.getString(cursor.getColumnIndex(myDbHelper.MINISTRY_NAME));
            ministryCount++;
        }
        Log.d("tag","Ministry count from db is :"+ String.valueOf(ministryArray.length));
        return ministryArray;
    }

    /**
     * GET RECORDS FROM SCHEMES TABLE (BOTH TAMIL AND ENGLISH)
     * @param selectedMinistryId
     * @return
     */
    public ArrayList<Scheme> getSchemesForSelectedMinistryFromDb_Eng(Integer selectedMinistryId){
        ArrayList<Scheme> schemesOfSelectedMinistry=new ArrayList<>();
        Scheme scheme=new Scheme();
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.SCHEME_ID, myDbHelper.SCHEME_NAME,myDbHelper.SCHEMES_DESC,myDbHelper.SCHEMES_OBJECTIVE ,myDbHelper.SCHEME_ELIGIBILITY,myDbHelper.SCHEME_TARGET,myDbHelper.SCHEME_DEPARTMENT,myDbHelper.SCHEME_MISC, myDbHelper.SCHEMES_MINISTRY_ID,};
        Cursor cursor = db.query(myDbHelper.SCHEMES_TABLE_NAME_ENG, columns, myDbHelper.SCHEMES_MINISTRY_ID + "=?", new String[] { String.valueOf(selectedMinistryId) }, null, null, null, null);

        while (cursor.moveToNext()) {
            scheme=new Scheme();
            scheme.setSchemeId(cursor.getInt(cursor.getColumnIndex(myDbHelper.SCHEME_ID)));
            scheme.setSchemeName(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_NAME)));
            scheme.setSchemeObjective(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEMES_OBJECTIVE)));
            scheme.setSchemeDescription(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEMES_DESC)));
            scheme.setSchemeEligibility(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_ELIGIBILITY)));
            scheme.setSchemeTargetGroup(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_TARGET)));
            scheme.setSchemeDepartment(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_DEPARTMENT)));
            scheme.setSchemeMiscDetails(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_MISC)));
            scheme.setSchemeMinistryId(cursor.getInt(cursor.getColumnIndex(myDbHelper.SCHEMES_MINISTRY_ID)));
            Log.d("tag", " selectedScheme before bundle 111111111 :"+scheme.getSchemeObjective());
            schemesOfSelectedMinistry.add(scheme);
        }
        return schemesOfSelectedMinistry;
    }
    public ArrayList<Scheme> getSchemesForSelectedMinistryFromDb_Tam(Integer selectedMinistryId){
        ArrayList<Scheme> schemesOfSelectedMinistry=new ArrayList<>();
        Scheme scheme=new Scheme();
        SQLiteDatabase db = myhelper.getWritableDatabase();
        String[] columns = {myDbHelper.SCHEME_ID, myDbHelper.SCHEME_NAME,myDbHelper.SCHEMES_DESC,myDbHelper.SCHEMES_OBJECTIVE ,myDbHelper.SCHEME_ELIGIBILITY,myDbHelper.SCHEME_TARGET,myDbHelper.SCHEME_DEPARTMENT,myDbHelper.SCHEME_MISC, myDbHelper.SCHEMES_MINISTRY_ID,};
        Cursor cursor = db.query(myDbHelper.SCHEMES_TABLE_NAME_TAMIL, columns, myDbHelper.SCHEMES_MINISTRY_ID + "=?", new String[] { String.valueOf(selectedMinistryId) }, null, null, null, null);

        while (cursor.moveToNext()) {
            scheme=new Scheme();
            scheme.setSchemeId(cursor.getInt(cursor.getColumnIndex(myDbHelper.SCHEME_ID)));
            scheme.setSchemeName(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_NAME)));
            scheme.setSchemeObjective(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEMES_OBJECTIVE)));
            scheme.setSchemeDescription(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEMES_DESC)));
            scheme.setSchemeEligibility(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_ELIGIBILITY)));
            scheme.setSchemeTargetGroup(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_TARGET)));
            scheme.setSchemeDepartment(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_DEPARTMENT)));
            scheme.setSchemeMiscDetails(cursor.getString(cursor.getColumnIndex(myDbHelper.SCHEME_MISC)));
            scheme.setSchemeMinistryId(cursor.getInt(cursor.getColumnIndex(myDbHelper.SCHEMES_MINISTRY_ID)));
            schemesOfSelectedMinistry.add(scheme);
            Log.d("tag","Scheme details  is :"+ scheme.getSchemeName() +" ~ "+scheme.getSchemeMinistryId());
        }
        return schemesOfSelectedMinistry;
    }

    /**
     * DROP ALL TABLES
     */
    public void dropDb() {
        SQLiteDatabase db = myhelper.getWritableDatabase();

        try {
            db.execSQL(myDbHelper.DROP_MINISTRY_TABLE_ENG);
            db.execSQL(myDbHelper.DROP_MINISTRY_TABLE_TAM);
            db.execSQL(myDbHelper.DROP_SCHEMES_TABLE_ENG);
            db.execSQL(myDbHelper.DROP_SCHEMES_TABLE_TAM);
        }catch (Exception e) {
        }
    }



    static class myDbHelper extends SQLiteOpenHelper
    {
        private static final String DATABASE_NAME = "MyGovShceme";
        private static final int DATABASE_Version = 1;
        /**
         * TABLE NAME : MINISTRY
         */
        private static final String MINISTRY_TABLE_NAME_ENG = "ministry_english";
        private static final String MINISTRY_TABLE_NAME_TAM = "ministry_tamil";
        /**
         *  COLUMN NAMES FOR MINISTRY TABLE
         */
        private static final String MINISTRY_ID="ministry_id";
        private static final String MINISTRY_NAME = "ministry_name";
        /**
         * TABLE NAME : SCHEMES
         */
        private static final String SCHEMES_TABLE_NAME_ENG = "schemes_english";
        private static final String SCHEMES_TABLE_NAME_TAMIL = "schemes_tamil";
        /**
         * COLUMN NAMES FOR SCHEMES TABLE
         */

        private static final String SCHEME_ID="scheme_id";
        private static final String SCHEME_UID="scheme_ui_id";
        private static final String SCHEME_NAME="scheme_name";
        private static final String SCHEMES_DESC="Scheme_desc";
        private static final String SCHEMES_OBJECTIVE="Scheme_obj";
        private static final String SCHEME_ELIGIBILITY="scheme_eligibility";
        private static final String SCHEME_TARGET="schme_target";
        private static final String SCHEME_DEPARTMENT="scheme_departments";
        private static final String SCHEME_MISC="scheme_misc";
        private static final String SCHEMES_MINISTRY_ID="scheme_ministry_id";

        /**
         * Variable for table creation
         */
        private static final String CREATE_MINISTRY_TABLE_ENG = "CREATE TABLE "+MINISTRY_TABLE_NAME_ENG+
                " ("+MINISTRY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+MINISTRY_NAME+" BLOB  );";
        private static final String CREATE_MINISTRY_TABLE_TAM = "CREATE TABLE "+MINISTRY_TABLE_NAME_TAM+
                " ("+MINISTRY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+MINISTRY_NAME+" BLOB  );";


        private static final String CREATE_SCHEME_TABLE_ENG = "CREATE TABLE "+SCHEMES_TABLE_NAME_ENG+
                " ("+SCHEME_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+SCHEME_UID+" TEXT ,"+SCHEME_NAME+"  TEXT ,"+SCHEMES_OBJECTIVE+" BLOB, "+SCHEMES_DESC+" BLOB , " +
                ""+SCHEME_ELIGIBILITY+" BLOB , "+SCHEME_TARGET+" BLOB , "+SCHEME_MISC+" BLOB , "+SCHEME_DEPARTMENT + "  BLOB ,"+SCHEMES_MINISTRY_ID+" INTEGER );";
        private static final String CREATE_SCHEME_TABLE_TAM = "CREATE TABLE "+SCHEMES_TABLE_NAME_TAMIL+
                " ("+SCHEME_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+SCHEME_UID+" TEXT ,"+SCHEME_NAME+" TEXT ,"+SCHEMES_OBJECTIVE+" BLOB, "+SCHEMES_DESC+" BLOB , " +
                ""+SCHEME_ELIGIBILITY+" BLOB , "+SCHEME_TARGET+" BLOB , "+SCHEME_MISC+" BLOB  , "+SCHEME_DEPARTMENT+" BLOB ,"+SCHEMES_MINISTRY_ID+" INTEGER );";
        /**
         * Variable for table drop
         */

        private static final String DROP_MINISTRY_TABLE_ENG ="DROP TABLE IF EXISTS "+MINISTRY_TABLE_NAME_ENG;
        private static final String DROP_MINISTRY_TABLE_TAM ="DROP TABLE IF EXISTS "+MINISTRY_TABLE_NAME_TAM;
        private static final String DROP_SCHEMES_TABLE_ENG ="DROP TABLE IF EXISTS "+SCHEMES_TABLE_NAME_ENG;
        private static final String DROP_SCHEMES_TABLE_TAM ="DROP TABLE IF EXISTS "+SCHEMES_TABLE_NAME_TAMIL;
        private Context context;
        public myDbHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_Version);
            this.context=context;
        }

        public void onCreate(SQLiteDatabase db) {

            try {
                db.execSQL(DROP_MINISTRY_TABLE_ENG);
                db.execSQL(DROP_MINISTRY_TABLE_TAM);

                db.execSQL(CREATE_MINISTRY_TABLE_ENG);
                db.execSQL(CREATE_MINISTRY_TABLE_TAM);

                db.execSQL(DROP_SCHEMES_TABLE_ENG);
                db.execSQL(DROP_SCHEMES_TABLE_TAM);

                db.execSQL(CREATE_SCHEME_TABLE_TAM);
                db.execSQL(CREATE_SCHEME_TABLE_ENG);
            } catch (Exception e) {
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try {
                db.execSQL(DROP_MINISTRY_TABLE_ENG);
                db.execSQL(DROP_MINISTRY_TABLE_TAM);
                db.execSQL(DROP_SCHEMES_TABLE_ENG);
                db.execSQL(DROP_SCHEMES_TABLE_TAM);
                onCreate(db);
            }catch (Exception e) {
            }
        }
    }
}