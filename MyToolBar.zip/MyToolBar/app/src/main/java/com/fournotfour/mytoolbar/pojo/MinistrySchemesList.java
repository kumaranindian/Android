package com.fournotfour.mytoolbar.pojo;


import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "schemeUiId",
        "schemeName",
        "schemeObj",
        "schemeDesc",
        "schemeEligiiblity",
        "schemeTargetGroup",
        "schemeMiscDetails",
        "schemeDepartments"
})
public class MinistrySchemesList {

    @JsonProperty("schemeUiId")
    private String schemeUiId;
    @JsonProperty("schemeName")
    private String schemeName;
    @JsonProperty("schemeObj")
    private String schemeObj;
    @JsonProperty("schemeDesc")
    private String schemeDesc;
    @JsonProperty("schemeEligiiblity")
    private String schemeEligiiblity;
    @JsonProperty("schemeTargetGroup")
    private String schemeTargetGroup;
    @JsonProperty("schemeMiscDetails")
    private String schemeMiscDetails;
    @JsonProperty("schemeDepartments")
    private String schemeDepartments;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("schemeUiId")
    public String getSchemeUiId() {
        return schemeUiId;
    }

    @JsonProperty("schemeUiId")
    public void setSchemeUiId(String schemeUiId) {
        this.schemeUiId = schemeUiId;
    }

    @JsonProperty("schemeName")
    public String getSchemeName() {
        return schemeName;
    }

    @JsonProperty("schemeName")
    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }

    @JsonProperty("schemeObj")
    public String getSchemeObj() {
        return schemeObj;
    }

    @JsonProperty("schemeObj")
    public void setSchemeObj(String schemeObj) {
        this.schemeObj = schemeObj;
    }

    @JsonProperty("schemeDesc")
    public String getSchemeDesc() {
        return schemeDesc;
    }

    @JsonProperty("schemeDesc")
    public void setSchemeDesc(String schemeDesc) {
        this.schemeDesc = schemeDesc;
    }

    @JsonProperty("schemeEligiiblity")
    public String getSchemeEligiiblity() {
        return schemeEligiiblity;
    }

    @JsonProperty("schemeEligiiblity")
    public void setSchemeEligiiblity(String schemeEligiiblity) {
        this.schemeEligiiblity = schemeEligiiblity;
    }

    @JsonProperty("schemeTargetGroup")
    public String getSchemeTargetGroup() {
        return schemeTargetGroup;
    }

    @JsonProperty("schemeTargetGroup")
    public void setSchemeTargetGroup(String schemeTargetGroup) {
        this.schemeTargetGroup = schemeTargetGroup;
    }

    @JsonProperty("schemeMiscDetails")
    public String getSchemeMiscDetails() {
        return schemeMiscDetails;
    }

    @JsonProperty("schemeMiscDetails")
    public void setSchemeMiscDetails(String schemeMiscDetails) {
        this.schemeMiscDetails = schemeMiscDetails;
    }

    @JsonProperty("schemeDepartments")
    public String getSchemeDepartments() {
        return schemeDepartments;
    }

    @JsonProperty("schemeDepartments")
    public void setSchemeDepartments(String schemeDepartments) {
        this.schemeDepartments = schemeDepartments;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}